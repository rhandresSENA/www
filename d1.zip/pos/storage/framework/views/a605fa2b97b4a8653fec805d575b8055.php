 
<?php $__env->startSection('title', 'Users lists'); ?>
 
<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('users.create')); ?>">New User</a>

    <table class="">
        <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Type</th>
            <th>Location</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
            <?php if($users->isEmpty()): ?>
                <tr>
                    <td colspan="5">Users dont exits.</td>
                </tr>
            <?php endif; ?>


            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                <td><?php echo e($user->email); ?> <?php echo e($user->email); ?></td>
                <td><?php echo e($user->phone_number); ?> <?php echo e($user->phone_number); ?></td>
                <td><?php echo e($user->type); ?> <?php echo e($user->type); ?></td>
                <td><?php echo e($user->location); ?> <?php echo e($user->location); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pos\resources\views/users/index.blade.php ENDPATH**/ ?>