 
<?php $__env->startSection('title', 'Create User'); ?>
 
 
<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('users.index')); ?>">Cancel</a>

    <form action="<?php echo e(route('users.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="first_name" id="first_name" placeholder="first_name">
        <input type="text" name="last_name" id="last_name" placeholder="last_name">
        <input type="email" name="email" id="email" placeholder="Email">
        <input type="phone" name="phone_number" id="phone_number" placeholder="phone Number">

        <button type="submit">Create</button>
        <button type="reset">Reset</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pos\resources\views/users/create.blade.php ENDPATH**/ ?>